package com.cg.mts.service;

public interface IPaymentService {

	public void processPaymentByCash();
	public void processPaymentByCard();
	
}
