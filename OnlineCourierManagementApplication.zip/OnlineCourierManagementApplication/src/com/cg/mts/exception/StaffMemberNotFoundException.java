package com.cg.mts.exception;

public class StaffMemberNotFoundException extends Exception {

}
