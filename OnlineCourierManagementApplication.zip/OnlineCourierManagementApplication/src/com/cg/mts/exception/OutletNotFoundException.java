package com.cg.mts.exception;

public class OutletNotFoundException extends Exception {

}
