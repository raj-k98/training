package com.cg.mts.exception;

public class OutletClosedException extends Exception {

}
