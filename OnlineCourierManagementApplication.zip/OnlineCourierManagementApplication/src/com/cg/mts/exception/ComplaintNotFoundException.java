package com.cg.mts.exception;

public class ComplaintNotFoundException extends Exception {

}
