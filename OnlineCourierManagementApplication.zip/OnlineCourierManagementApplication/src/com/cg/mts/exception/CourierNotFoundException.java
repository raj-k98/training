package com.cg.mts.exception;

public class CourierNotFoundException extends Exception {

}
