package com.cg.mts.entities;

public class Address {
	private String street;
	private String city;
	private String state;
	private String country;
	private int zip;
}
