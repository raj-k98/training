package com.cg.mts.entities;

public class Complaint {

	private int complaintid;
	private int consignmentno;
	private String shortdescription;
	private String detaildescription;
	private Customer customer;
	
}
