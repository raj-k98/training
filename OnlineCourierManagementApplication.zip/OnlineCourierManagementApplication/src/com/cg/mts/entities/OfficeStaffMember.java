package com.cg.mts.entities;

public class OfficeStaffMember {

	protected int empid;
	protected String name;
	protected Address address;
	protected String role;
	protected CourierOfficeOutlet office;
}
