package com.cg.mts.entities;

import java.util.List;

public class Manager extends OfficeStaffMember {

	private List<OfficeStaffMember> reportingstaffmembers;
}
