package com.cg.mts.entities;

public class BankAccount {

	private int accountno;
	private String accountHolderName;
	private String accountType;
}
