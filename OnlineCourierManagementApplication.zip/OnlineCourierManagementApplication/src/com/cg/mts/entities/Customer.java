package com.cg.mts.entities;

public class Customer {

	private int customerid;
	private int aadharno;
	private String firstname;
	private String lastname;
	private Address addr;
	private int mobileno;
	private BankAccount acct;
	
}
