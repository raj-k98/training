package com.cg.mts.entities;

public enum CourierStatus {

	iniated, intransit, delivered, rejected;
}
