package com.cg.stockapp.dto;
public class Stock  {
private int stockId;
	private String companyId;
	private String investorId;
	private String stockName;
	private int quantity;
	private String type;
	private double avgPrice;
	private int totalNoOfStocks;
	private double profitLoss;
	private String status;
	
}
