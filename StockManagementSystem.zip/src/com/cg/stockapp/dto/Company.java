package com.cg.stockapp.dto;


public class Company {

	private static final long serialVersionUID = 1L;
	private String companyId;
	private String companyName;
	private Manager manager;
	private int noOfStocks;
	private double stockPrice;
	private double percentageChange;	
}
