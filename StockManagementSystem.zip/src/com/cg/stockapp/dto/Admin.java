package com.cg.stockapp.dto;

public class Admin {
	private String adminId;
	private String adminName;
	private String email;
	private String password;	
}
