package com.cg.stockapp.dto;

public class BankAccount {
	private String bankName;
	private String branchName;
	private long accountNo;
	private double balance;
}
