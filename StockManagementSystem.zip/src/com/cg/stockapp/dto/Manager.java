package com.cg.stockapp.dto;


public class Manager  {
private String managerId;
private String managerName;
private Company company;
private String email;
private String mobileNo;	
}
