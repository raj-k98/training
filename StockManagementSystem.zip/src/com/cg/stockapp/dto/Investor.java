package com.cg.stockapp.dto;


public class Investor {

	private static final long serialVersionUID = 1L;

	private String investorId;
	private String investorName;
	private String email;
	private String password;
	private String mobileNo;
	private String gender;
	private BankAccount account;

	
}
