package com.cg.salon.bean;

import java.time.LocalDate;

public class SalonService {
	private long serviceId;
	private String serviceName;
	private double price;
	private int discount;
	private String duration;
}
