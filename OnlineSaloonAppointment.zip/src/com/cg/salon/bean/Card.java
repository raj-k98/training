package com.cg.salon.bean;

import java.time.LocalDate;

public class Card {
	private String cardName;
	private String cardNumber;
    private LocalDate cardExpiry;
    private int cvv;
}
