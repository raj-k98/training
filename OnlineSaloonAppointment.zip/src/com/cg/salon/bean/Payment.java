package com.cg.salon.bean;

public class Payment {
	private long paymentId;
	private String type;
	private String status;
	private Card card;
}
