package com.cg.salon.bean;

import java.time.LocalDate;

public class Customer {
	
	private String userId;
	private String name;
	private String email;
	private String contactNo;
	private  LocalDate dob;
	private Address address;

}
