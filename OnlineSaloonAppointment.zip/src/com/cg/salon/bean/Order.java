package com.cg.salon.bean;

import java.time.LocalDate;

public class Order {
	private long orderId;
	private double amount;
	private LocalDate billingDate;
	private Customer customer;

}
