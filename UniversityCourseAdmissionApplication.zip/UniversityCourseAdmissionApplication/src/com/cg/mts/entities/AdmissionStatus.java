package com.cg.mts.entities;

public enum AdmissionStatus {
Applied,Pending,Confirmed,Rejected;
}
