package com.cg.mts.entities;

import java.util.List;

public class Applicant {
private String applicantId;
private String applicantName;
private String mobileNumber;
private String applicantDegree;
private int applicantGraduationPercent;
private Admission admission;
private AdmissionStatus status;

}
