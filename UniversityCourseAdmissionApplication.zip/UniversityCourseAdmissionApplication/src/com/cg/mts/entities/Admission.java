package com.cg.mts.entities;

import java.time.LocalDate;
import java.util.List;

public class Admission {
private int admissionId;
private int courseId;
private int applicantId;
private LocalDate admissionDate;
private AdmissionStatus status;


}
