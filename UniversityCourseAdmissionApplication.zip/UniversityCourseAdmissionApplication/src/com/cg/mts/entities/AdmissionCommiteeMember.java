package com.cg.mts.entities;

public class AdmissionCommiteeMember {
private int adminId;
private String adminName;
private String adminContact;
}
