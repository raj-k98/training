package com.cg.mts.entities;

public class UniversityStaffMember {
private int staffId;
private String password;
private String role;

}
