package com.cg.mts.entities;

import java.time.LocalDate;

public class Course {

	private int courseId;
	private String courseName;
	private String courseDuration;
	private LocalDate courseStartDate;
	private LocalDate courseEndDate;
	private String courseFees;
	
}
