package com.cg.mts.exception;

public class LoginFailedException extends Exception {

}
