package com.cg.mts.exception;

public class AdmissionNotGrantedException extends Exception {

}
