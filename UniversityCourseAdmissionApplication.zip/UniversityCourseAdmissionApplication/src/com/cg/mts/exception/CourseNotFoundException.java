package com.cg.mts.exception;

public class CourseNotFoundException extends Exception {

}
