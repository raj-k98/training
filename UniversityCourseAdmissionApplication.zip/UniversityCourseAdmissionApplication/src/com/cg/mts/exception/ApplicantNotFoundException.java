package com.cg.mts.exception;

public class ApplicantNotFoundException extends Exception {

}
