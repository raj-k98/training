package com.cg.fms.dao;

import java.util.List;

import com.cg.fms.dto.Customer;


public interface CustomerDao {
	public boolean loginCustomer(String customerName, String customerPassword);

	public Customer getCustomer(String customerId);

	public boolean addCustomer(Customer customer);

	public boolean updateCustomer(Customer customer);

	public boolean deleteCustomer(String customerId);
	
	public List<Customer> getAllCustomers();
}
