package com.cg.fms.dao;

import java.util.List;

import com.cg.fms.dto.Orders;

public interface IOrderDao {

	public Orders getOrder(String orderNumber);

	public boolean addOrder(Orders order);

	public boolean updateOrder(Orders order);

	public boolean deleteOrder(String orderNumber);
	
	public List<Orders> getAllOrders();
}
