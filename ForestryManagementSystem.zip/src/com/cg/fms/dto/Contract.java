package com.cg.fms.dto;

import java.util.List;

public class Contract{
	
	private String contractNumber;
	private Customer customer;
	private Product product;
	private String deliveryPlace;
	private String deliveryDate;
	private String quantity;
	private Scheduler scheduler;
}
