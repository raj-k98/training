package com.cg.fms.dto;

public class Land  {
	private int landId;
private String surveyNumber;
private String ownerName;
private String landArea;
	
}
