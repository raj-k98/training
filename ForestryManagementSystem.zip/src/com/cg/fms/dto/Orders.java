package com.cg.fms.dto;

public class Orders{
	private String orderNumber;
	private Contract contract;
	private Customer customer;
	private Product product;
	private String deliveryPlace;
	private String deliveryDate;
	private String quantity;
	private Scheduler scheduler;
}
