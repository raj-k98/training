package com.cg.fms.dto;


public class Admin{
	private int adminId;
	private String adminName;
	private String adminPassword;

}
