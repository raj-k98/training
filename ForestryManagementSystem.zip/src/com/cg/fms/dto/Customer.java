package com.cg.fms.dto;


public class Customer{
	private String customerId;
	private String customerPassword;
	private String customerName;
	private String customerEmail;
	private String customerAddress;
	private String customerTown;
	private String customerPostalCode;
	private String customerContact;
}
