package com.cg.fms.dto;

public class User {

	private String userName;
	private String password;
	private String role;
	
}
